package headfirst.command;

public class DimmerLightOffCommand implements Command {
	Light light;
	int prevLevel;
	@Override
	public void execute() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}

	
}
