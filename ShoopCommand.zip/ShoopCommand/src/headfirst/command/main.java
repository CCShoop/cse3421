/*package headfirst.command;

public class main {

	public static void main(String[] args) {
		Projector projector = new Projector();
		
		Screen screen = new Screen();
		
		Light classroomLight = new Light("Classroom");
		
		classroomLight.dim(15);
		screen.drop();
		projector.on();
		
		classroomLight.on();
		screen.raise();
		projector.off();
	}

}
*/