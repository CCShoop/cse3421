//Cael Shoop
//Pattern Assignment 2

public class StarbuzzCoffee {
	public static void main(String[] args) {
		Store store1 = new Store();
		store1.createStore();
	}
}
