/*
 * Cael Shoop
 * CSE3421
 * Pattern Assignment 1
 * Part 2
 * AService Class
 */

public class AService implements IAService {
	public void provideService() {
		System.out.println("I'm now providing the service for MyController");
	}
}
