/*
 * Cael Shoop
 * CSE3421
 * Pattern Assignment 1
 * Part 2
 * ExampleFactory Class
 */

class ExampleFactory {
	private static ExampleFactory object = null;
	
	public static ExampleFactory getInstance() {
		if (object == null) {
			object = new ExampleFactory();
		}
		return object;
	}
	
	public IAService getService() {
		return new AService();
	}
}
