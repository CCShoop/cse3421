/*
 * Cael Shoop
 * CSE3421
 * Pattern Assignment 1
 * Part 2
 * IAService Interface
 */

public interface IAService {
	public void provideService();
}
