/*
 * Cael Shoop
 * CSE3421
 * Pattern Assignment 1
 * Part 2
 * MyController Class
 */

public class MyController {

	public static void main(String[] args) {
		IAService service = ExampleFactory.getInstance().getService();
		service.provideService();
	}

}
