/*
 * Cael Shoop
 * CSE3421
 * Pattern Assignment 1
 * Part 1
 * Main Class
 */

public class MainClass {

	public static void main(String[] args) {
		ServiceProvider object1 = ServiceProvider.getInstance();
		ServiceProvider object2 = ServiceProvider.getInstance();
		ServiceProvider object3 = ServiceProvider.getInstance();
	}

}
