/*
 * Cael Shoop
 * CSE3421
 * Pattern Assignment 1
 * Part 1
 * ServiceProvider Class
 */

class ServiceProvider {
	private static ServiceProvider object = null;
	
	public static ServiceProvider getInstance() {
		if (object == null) {
			object = new ServiceProvider();
			System.out.println("Constructing ServiceProvider");
		}
		else {
			System.out.println("ServiceProvider already exists");
		}
		return object;
	}
}
